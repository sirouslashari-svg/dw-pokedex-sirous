// Shared helpers used by both the list view (index.js) and the detail view (detail.js).

export const API_BASE = 'https://pokeapi.co/api/v2';

// Standard Pokémon-type colour palette, used for the detail page background (ekstraopgave 1)
// and for type badges.
export const TYPE_COLORS = {
  normal: '#A8A77A',
  fire: '#EE8130',
  water: '#6390F0',
  electric: '#F7D02C',
  grass: '#7AC74C',
  ice: '#96D9D6',
  fighting: '#C22E28',
  poison: '#A33EA1',
  ground: '#E2BF65',
  flying: '#A98FF3',
  psychic: '#F95587',
  bug: '#A6B91A',
  rock: '#B6A136',
  ghost: '#735797',
  dragon: '#6F35FC',
  dark: '#705746',
  steel: '#B7B7CE',
  fairy: '#D685AD'
};

/**
 * Fetches JSON from the given URL and throws a readable error on failure.
 */
export async function fetchJSON(url) {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Request failed (${response.status}): ${url}`);
  }
  return response.json();
}

/**
 * Capitalises the first letter of a string, e.g. "ivysaur" -> "Ivysaur".
 */
export function capitalize(text) {
  if (!text) return '';
  return text.charAt(0).toUpperCase() + text.slice(1);
}

/**
 * Extracts the numeric Pokémon ID from a PokeAPI resource URL.
 * e.g. "https://pokeapi.co/api/v2/pokemon/25/" -> "25"
 */
export function getIdFromUrl(url) {
  const parts = url.split('/').filter(Boolean);
  return parts[parts.length - 1];
}

/**
 * Full-size official artwork image for a given Pokémon ID.
 */
export function getArtworkUrl(id) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`;
}

/**
 * Smaller, classic sprite image — used as a fallback if the artwork fails to load.
 */
export function getSpriteUrl(id) {
  return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${id}.png`;
}
