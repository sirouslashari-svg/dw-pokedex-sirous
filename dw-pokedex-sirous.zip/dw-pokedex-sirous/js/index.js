// List view (forsiden): fetches a batch of Pokémon and renders each one
// wrapped in a link to detail.html?name=<pokemon-name>.
// Includes a functional search field and a sort-by-number/name toggle,
// matching the Figma design.

import { API_BASE, capitalize, getIdFromUrl, getArtworkUrl, getSpriteUrl, fetchJSON } from './api.js';

const root = document.getElementById('root');

// How many Pokémon to fetch and show on the list page.
const POKEMON_COUNT = 151;

let allPokemon = [];
// 'number' sorts by Pokédex id (default), 'name' sorts alphabetically.
let sortMode = 'number';

function renderLayout() {
  root.innerHTML = `
    <header class="site-header">
      <div class="site-header__logo">
        <span class="pokeball-icon" aria-hidden="true"></span>
        <h1 class="logo">Pokédex</h1>
      </div>
      <div class="search-row">
        <label class="search-field">
          <svg class="search-field__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>
          </svg>
          <input type="search" id="searchInput" placeholder="Search" autocomplete="off">
        </label>
        <button type="button" class="sort-toggle" id="sortToggle" aria-pressed="false" title="Sortér efter navn / nummer">#</button>
      </div>
    </header>
    <p class="status" id="status">Indlæser Pokémon...</p>
    <ul class="pokemon-grid" id="pokemonGrid"></ul>
  `;
}

function createPokemonCard(pokemon) {
  const li = document.createElement('li');
  li.className = 'pokemon-card';

  const link = document.createElement('a');
  link.className = 'pokemon-card__link';
  link.href = `detail.html?name=${encodeURIComponent(pokemon.name)}`;

  const imgWrap = document.createElement('div');
  imgWrap.className = 'pokemon-card__image-wrap';

  const idBadge = document.createElement('span');
  idBadge.className = 'pokemon-card__id';
  idBadge.textContent = `#${String(pokemon.id).padStart(3, '0')}`;

  const img = document.createElement('img');
  img.className = 'pokemon-card__image';
  img.alt = pokemon.name;
  img.src = getArtworkUrl(pokemon.id);
  img.width = 96;
  img.height = 96;
  // If the full artwork is missing for a given Pokémon, fall back to the classic sprite.
  img.addEventListener('error', () => {
    if (img.src !== getSpriteUrl(pokemon.id)) {
      img.src = getSpriteUrl(pokemon.id);
    }
  });

  imgWrap.appendChild(idBadge);
  imgWrap.appendChild(img);

  const name = document.createElement('span');
  name.className = 'pokemon-card__name';
  name.textContent = capitalize(pokemon.name);

  link.appendChild(imgWrap);
  link.appendChild(name);
  li.appendChild(link);
  return li;
}

function getVisibleList() {
  const term = document.getElementById('searchInput').value.trim().toLowerCase();
  let list = term
    ? allPokemon.filter(p => p.name.includes(term))
    : allPokemon.slice();

  if (sortMode === 'name') {
    list = list.slice().sort((a, b) => a.name.localeCompare(b.name));
  } else {
    list = list.slice().sort((a, b) => Number(a.id) - Number(b.id));
  }
  return list;
}

function renderPokemonList() {
  const grid = document.getElementById('pokemonGrid');
  const status = document.getElementById('status');
  const list = getVisibleList();

  grid.innerHTML = '';

  if (list.length === 0) {
    status.textContent = 'Ingen Pokémon fundet.';
    status.hidden = false;
    return;
  }
  status.hidden = true;

  const fragment = document.createDocumentFragment();
  list.forEach(pokemon => {
    fragment.appendChild(createPokemonCard(pokemon));
  });
  grid.appendChild(fragment);
}

function setupSearch() {
  document.getElementById('searchInput').addEventListener('input', renderPokemonList);
}

function setupSortToggle() {
  const button = document.getElementById('sortToggle');
  button.addEventListener('click', () => {
    sortMode = sortMode === 'number' ? 'name' : 'number';
    button.textContent = sortMode === 'number' ? '#' : 'A';
    button.setAttribute('aria-pressed', String(sortMode === 'name'));
    renderPokemonList();
  });
}

async function init() {
  renderLayout();
  setupSearch();
  setupSortToggle();
  try {
    const data = await fetchJSON(`${API_BASE}/pokemon?limit=${POKEMON_COUNT}&offset=0`);
    allPokemon = data.results.map(pokemon => ({
      name: pokemon.name,
      url: pokemon.url,
      id: getIdFromUrl(pokemon.url)
    }));
    renderPokemonList();
  } catch (error) {
    console.error(error);
    const status = document.getElementById('status');
    status.textContent = 'Kunne ikke hente Pokémon-listen. Prøv igen senere.';
    status.hidden = false;
  }
}

init();
