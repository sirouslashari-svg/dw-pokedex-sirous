// Detail view: reads ?name= (or a numeric id) from the URL, fetches that
// Pokémon (plus its species record for the flavour-text description) and
// renders it to match the Figma detail-page design.

import { API_BASE, TYPE_COLORS, capitalize, fetchJSON, getArtworkUrl, getSpriteUrl } from './api.js';

const root = document.getElementById('root');

// Reasonable upper bound so the "next Pokémon" arrow doesn't try to fetch
// an id that doesn't exist.
const MAX_POKEMON_ID = 1025;

function getNameFromUrl() {
  return new URLSearchParams(window.location.search).get('name');
}

function renderLoading() {
  root.innerHTML = `<p class="status">Indlæser Pokémon...</p>`;
}

function renderError(message) {
  root.innerHTML = `
    <div class="detail-error">
      <p class="status status--error">${message}</p>
      <a class="back-link" href="index.html">&larr; Tilbage til listen</a>
    </div>
  `;
}

function formatDecimal(number) {
  // Danish-style decimal comma, e.g. 6.9 -> "6,9"
  return number.toString().replace('.', ',');
}

function getFlavorText(species) {
  const entry = species.flavor_text_entries.find(e => e.language.name === 'en');
  if (!entry) return '';
  return entry.flavor_text.replace(/[\n\f\u00ad]/g, ' ').replace(/\s+/g, ' ').trim();
}

function statBar(stat, color) {
  const percent = Math.min(100, Math.round((stat.base_stat / 180) * 100));
  const label = stat.stat.name
    .replace('special-attack', 'SATK')
    .replace('special-defense', 'SDEF')
    .replace('attack', 'ATK')
    .replace('defense', 'DEF')
    .replace('speed', 'SPD')
    .replace('hp', 'HP')
    .toUpperCase();
  const value = String(stat.base_stat).padStart(3, '0');
  return `
    <li class="stat-row">
      <span class="stat-row__label" style="color:${color}">${label}</span>
      <span class="stat-row__value">${value}</span>
      <div class="stat-row__bar"><div class="stat-row__fill" style="width:${percent}%; background:${color}"></div></div>
    </li>
  `;
}

function iconWeight() {
  return `<svg viewBox="0 0 24 24" class="about-icon" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M7 8h10l1.5 12h-13L7 8Z"/><path d="M9 8a3 3 0 0 1 6 0"/></svg>`;
}

function iconHeight() {
  return `<svg viewBox="0 0 24 24" class="about-icon" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="7" y="3" width="10" height="18" rx="1.5"/><path d="M7 8h3M7 13h3M7 18h3"/></svg>`;
}

function render(pokemon, species) {
  const primaryType = pokemon.types[0]?.type.name || 'normal';
  const color = TYPE_COLORS[primaryType] || '#A8A77A';

  const typesHtml = pokemon.types
    .map(t => `<span class="type-badge" style="background:${TYPE_COLORS[t.type.name] || '#999'}">${capitalize(t.type.name)}</span>`)
    .join('');

  const abilitiesHtml = pokemon.abilities
    .map(a => capitalize(a.ability.name.replace(/-/g, ' ')))
    .join('<br>');

  const statsHtml = pokemon.stats.map(stat => statBar(stat, color)).join('');
  const description = getFlavorText(species);
  const id = pokemon.id;
  const hasNext = id < MAX_POKEMON_ID;

  root.innerHTML = `
    <article class="detail-page">
      <header class="detail-header" style="background:${color}">
        <a class="detail-header__back" href="index.html" aria-label="Tilbage til listen">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 5 8 12l7 7"/></svg>
        </a>
        <div class="detail-header__pokeball" aria-hidden="true"></div>
        <div class="detail-header__title-row">
          <h1 class="detail-header__name">${capitalize(pokemon.name)}</h1>
          <span class="detail-header__id">#${String(id).padStart(3, '0')}</span>
        </div>
        <img class="detail-header__image" src="${getArtworkUrl(id)}" alt="${pokemon.name}"
             onerror="this.onerror=null;this.src='${getSpriteUrl(id)}'">
        ${hasNext ? `
          <a class="detail-header__next" href="detail.html?name=${id + 1}" aria-label="N\u00e6ste Pok\u00e9mon">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>
          </a>
        ` : ''}
      </header>

      <section class="detail-card">
        <div class="type-badge-list">${typesHtml}</div>

        <h2 class="section-title" style="color:${color}">About</h2>
        <div class="about-row">
          <div class="about-col">
            ${iconWeight()}
            <span class="about-col__value">${formatDecimal(pokemon.weight / 10)} kg</span>
            <span class="about-col__label">Weight</span>
          </div>
          <div class="about-col">
            ${iconHeight()}
            <span class="about-col__value">${formatDecimal(pokemon.height / 10)} m</span>
            <span class="about-col__label">Height</span>
          </div>
          <div class="about-col">
            <span class="about-col__value about-col__value--text">${abilitiesHtml}</span>
            <span class="about-col__label">Moves</span>
          </div>
        </div>

        ${description ? `<p class="description">${description}</p>` : ''}

        <h2 class="section-title" style="color:${color}">Base Stats</h2>
        <ul class="stat-list">${statsHtml}</ul>
      </section>
    </article>
  `;
}

async function init() {
  const name = getNameFromUrl();
  if (!name) {
    renderError('Ingen Pokémon valgt. Gå tilbage til listen og vælg én.');
    return;
  }
  renderLoading();
  try {
    const normalized = name.toLowerCase();
    const [pokemon, species] = await Promise.all([
      fetchJSON(`${API_BASE}/pokemon/${encodeURIComponent(normalized)}`),
      fetchJSON(`${API_BASE}/pokemon-species/${encodeURIComponent(normalized)}`)
    ]);
    render(pokemon, species);
  } catch (error) {
    console.error(error);
    renderError(`Kunne ikke finde Pokémonen "${name}".`);
  }
}

init();
